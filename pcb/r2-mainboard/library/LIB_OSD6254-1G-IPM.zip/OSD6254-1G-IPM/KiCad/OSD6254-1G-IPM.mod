PCBNEW-LibModule-V1  2026-09-11 12:32:27
# encoding utf-8
Units mm
$INDEX
BGA500C50P28X18_1400X900X130
$EndINDEX
$MODULE BGA500C50P28X18_1400X900X130
Po 0 0 0 15 6aa3f4db 00000000 ~~
Li BGA500C50P28X18_1400X900X130
Cd 500-LFBGA (9x14)
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "BGA500C50P28X18_1400X900X130"
DS -8 -5.5 8 -5.5 0.05 24
DS 8 -5.5 8 5.5 0.05 24
DS 8 5.5 -8 5.5 0.05 24
DS -8 5.5 -8 -5.5 0.05 24
DS -7 -4.5 7 -4.5 0.1 24
DS 7 -4.5 7 4.5 0.1 24
DS 7 4.5 -7 4.5 0.1 24
DS -7 4.5 -7 -4.5 0.1 24
DS -7 -2.25 -4.75 -4.5 0.1 24
DS -6.75 -4.7 7.2 -4.7 0.2 21
DS 7.2 -4.7 7.2 4.7 0.2 21
DS 7.2 4.7 -7.2 4.7 0.2 21
DS -7.2 4.7 -7.2 -4.25 0.2 21
DS -7.2 -4.25 -6.75 -4.7 0.2 21
DC -7.2 -4.7 -7.1 -4.7 0.254 21
$PAD
Po -6.25 -4.25
Sh "A2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -4.25
Sh "A3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -4.25
Sh "A4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -4.25
Sh "A5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -4.25
Sh "A6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -4.25
Sh "A7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -4.25
Sh "A8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -4.25
Sh "A9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -4.25
Sh "A10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -4.25
Sh "A11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -4.25
Sh "A12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -4.25
Sh "A13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -4.25
Sh "A14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -4.25
Sh "A15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -4.25
Sh "A16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -4.25
Sh "A17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -4.25
Sh "A18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -4.25
Sh "A19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -4.25
Sh "A20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -4.25
Sh "A21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -4.25
Sh "A22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -4.25
Sh "A23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -4.25
Sh "A24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -4.25
Sh "A25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -4.25
Sh "A26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -4.25
Sh "A27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -3.75
Sh "B1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -3.75
Sh "B2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -3.75
Sh "B3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -3.75
Sh "B4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -3.75
Sh "B5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -3.75
Sh "B6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -3.75
Sh "B7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -3.75
Sh "B8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -3.75
Sh "B9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -3.75
Sh "B10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -3.75
Sh "B11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -3.75
Sh "B12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -3.75
Sh "B13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -3.75
Sh "B14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -3.75
Sh "B15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -3.75
Sh "B16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -3.75
Sh "B17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -3.75
Sh "B18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -3.75
Sh "B19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -3.75
Sh "B20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -3.75
Sh "B21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -3.75
Sh "B22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -3.75
Sh "B23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -3.75
Sh "B24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -3.75
Sh "B25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -3.75
Sh "B26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -3.75
Sh "B27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -3.75
Sh "B28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -3.25
Sh "C1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -3.25
Sh "C2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -3.25
Sh "C3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -3.25
Sh "C4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -3.25
Sh "C5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -3.25
Sh "C6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -3.25
Sh "C7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -3.25
Sh "C8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -3.25
Sh "C9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -3.25
Sh "C10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -3.25
Sh "C11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -3.25
Sh "C12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -3.25
Sh "C13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -3.25
Sh "C14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -3.25
Sh "C15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -3.25
Sh "C16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -3.25
Sh "C17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -3.25
Sh "C18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -3.25
Sh "C19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -3.25
Sh "C20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -3.25
Sh "C21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -3.25
Sh "C22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -3.25
Sh "C23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -3.25
Sh "C24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -3.25
Sh "C25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -3.25
Sh "C26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -3.25
Sh "C27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -3.25
Sh "C28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -2.75
Sh "D1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -2.75
Sh "D2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -2.75
Sh "D3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -2.75
Sh "D4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -2.75
Sh "D5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -2.75
Sh "D6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -2.75
Sh "D7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -2.75
Sh "D8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -2.75
Sh "D9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -2.75
Sh "D10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -2.75
Sh "D11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -2.75
Sh "D12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -2.75
Sh "D13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -2.75
Sh "D14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -2.75
Sh "D15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -2.75
Sh "D16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -2.75
Sh "D17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -2.75
Sh "D18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -2.75
Sh "D19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -2.75
Sh "D20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -2.75
Sh "D21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -2.75
Sh "D22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -2.75
Sh "D23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -2.75
Sh "D24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -2.75
Sh "D25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -2.75
Sh "D26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -2.75
Sh "D27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -2.75
Sh "D28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -2.25
Sh "E1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -2.25
Sh "E2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -2.25
Sh "E3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -2.25
Sh "E4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -2.25
Sh "E5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -2.25
Sh "E6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -2.25
Sh "E7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -2.25
Sh "E8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -2.25
Sh "E9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -2.25
Sh "E10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -2.25
Sh "E11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -2.25
Sh "E12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -2.25
Sh "E13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -2.25
Sh "E14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -2.25
Sh "E15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -2.25
Sh "E16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -2.25
Sh "E17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -2.25
Sh "E18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -2.25
Sh "E19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -2.25
Sh "E20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -2.25
Sh "E21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -2.25
Sh "E22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -2.25
Sh "E23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -2.25
Sh "E24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -2.25
Sh "E25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -2.25
Sh "E26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -2.25
Sh "E27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -2.25
Sh "E28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -1.75
Sh "F1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -1.75
Sh "F2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -1.75
Sh "F3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -1.75
Sh "F4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -1.75
Sh "F5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -1.75
Sh "F6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -1.75
Sh "F7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -1.75
Sh "F8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -1.75
Sh "F9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -1.75
Sh "F10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -1.75
Sh "F11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -1.75
Sh "F12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -1.75
Sh "F13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -1.75
Sh "F14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -1.75
Sh "F15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -1.75
Sh "F16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -1.75
Sh "F17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -1.75
Sh "F18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -1.75
Sh "F19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -1.75
Sh "F20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -1.75
Sh "F21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -1.75
Sh "F22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -1.75
Sh "F23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -1.75
Sh "F24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -1.75
Sh "F25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -1.75
Sh "F26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -1.75
Sh "F27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -1.75
Sh "F28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -1.25
Sh "G1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -1.25
Sh "G2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -1.25
Sh "G3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -1.25
Sh "G4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -1.25
Sh "G5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -1.25
Sh "G6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -1.25
Sh "G7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -1.25
Sh "G8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -1.25
Sh "G9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -1.25
Sh "G10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -1.25
Sh "G11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -1.25
Sh "G12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -1.25
Sh "G13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -1.25
Sh "G14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -1.25
Sh "G15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -1.25
Sh "G16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -1.25
Sh "G17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -1.25
Sh "G18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -1.25
Sh "G19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -1.25
Sh "G20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -1.25
Sh "G21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -1.25
Sh "G22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -1.25
Sh "G23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -1.25
Sh "G24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -1.25
Sh "G25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -1.25
Sh "G26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -1.25
Sh "G27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -1.25
Sh "G28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -0.75
Sh "H1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -0.75
Sh "H2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -0.75
Sh "H3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -0.75
Sh "H4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -0.75
Sh "H5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -0.75
Sh "H6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -0.75
Sh "H7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -0.75
Sh "H8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -0.75
Sh "H9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -0.75
Sh "H10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -0.75
Sh "H11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -0.75
Sh "H12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -0.75
Sh "H13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -0.75
Sh "H14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -0.75
Sh "H15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -0.75
Sh "H16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -0.75
Sh "H17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -0.75
Sh "H18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -0.75
Sh "H19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -0.75
Sh "H20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -0.75
Sh "H21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -0.75
Sh "H22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -0.75
Sh "H23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -0.75
Sh "H24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -0.75
Sh "H25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -0.75
Sh "H26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -0.75
Sh "H27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -0.75
Sh "H28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 -0.25
Sh "J1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 -0.25
Sh "J2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 -0.25
Sh "J3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 -0.25
Sh "J4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 -0.25
Sh "J5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 -0.25
Sh "J6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 -0.25
Sh "J7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 -0.25
Sh "J8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 -0.25
Sh "J9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 -0.25
Sh "J10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 -0.25
Sh "J11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 -0.25
Sh "J12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -0.25
Sh "J13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -0.25
Sh "J14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -0.25
Sh "J15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -0.25
Sh "J16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 -0.25
Sh "J17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 -0.25
Sh "J18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 -0.25
Sh "J19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 -0.25
Sh "J20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 -0.25
Sh "J21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 -0.25
Sh "J22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 -0.25
Sh "J23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 -0.25
Sh "J24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 -0.25
Sh "J25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 -0.25
Sh "J26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 -0.25
Sh "J27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 -0.25
Sh "J28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 0.25
Sh "K1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 0.25
Sh "K2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 0.25
Sh "K3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 0.25
Sh "K4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 0.25
Sh "K5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 0.25
Sh "K6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 0.25
Sh "K7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 0.25
Sh "K8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 0.25
Sh "K9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 0.25
Sh "K10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 0.25
Sh "K11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 0.25
Sh "K12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 0.25
Sh "K13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 0.25
Sh "K14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 0.25
Sh "K15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 0.25
Sh "K16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 0.25
Sh "K17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 0.25
Sh "K18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 0.25
Sh "K19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 0.25
Sh "K20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 0.25
Sh "K21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 0.25
Sh "K22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 0.25
Sh "K23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 0.25
Sh "K24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 0.25
Sh "K25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 0.25
Sh "K26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 0.25
Sh "K27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 0.25
Sh "K28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 0.75
Sh "L1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 0.75
Sh "L2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 0.75
Sh "L3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 0.75
Sh "L4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 0.75
Sh "L5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 0.75
Sh "L6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 0.75
Sh "L7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 0.75
Sh "L8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 0.75
Sh "L9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 0.75
Sh "L10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 0.75
Sh "L11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 0.75
Sh "L12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 0.75
Sh "L13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 0.75
Sh "L14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 0.75
Sh "L15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 0.75
Sh "L16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 0.75
Sh "L17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 0.75
Sh "L18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 0.75
Sh "L19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 0.75
Sh "L20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 0.75
Sh "L21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 0.75
Sh "L22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 0.75
Sh "L23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 0.75
Sh "L24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 0.75
Sh "L25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 0.75
Sh "L26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 0.75
Sh "L27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 0.75
Sh "L28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 1.25
Sh "M1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 1.25
Sh "M2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 1.25
Sh "M3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 1.25
Sh "M4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 1.25
Sh "M5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 1.25
Sh "M6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 1.25
Sh "M7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 1.25
Sh "M8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 1.25
Sh "M9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 1.25
Sh "M10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 1.25
Sh "M11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 1.25
Sh "M12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 1.25
Sh "M13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 1.25
Sh "M14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 1.25
Sh "M15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 1.25
Sh "M16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 1.25
Sh "M17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 1.25
Sh "M18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 1.25
Sh "M19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 1.25
Sh "M20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 1.25
Sh "M21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 1.25
Sh "M22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 1.25
Sh "M23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 1.25
Sh "M24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 1.25
Sh "M25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 1.25
Sh "M26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 1.25
Sh "M27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 1.25
Sh "M28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 1.75
Sh "N1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 1.75
Sh "N2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 1.75
Sh "N3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 1.75
Sh "N4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 1.75
Sh "N5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 1.75
Sh "N6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 1.75
Sh "N7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 1.75
Sh "N8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 1.75
Sh "N9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 1.75
Sh "N10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 1.75
Sh "N11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 1.75
Sh "N12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 1.75
Sh "N13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 1.75
Sh "N14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 1.75
Sh "N15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 1.75
Sh "N16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 1.75
Sh "N17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 1.75
Sh "N18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 1.75
Sh "N19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 1.75
Sh "N20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 1.75
Sh "N21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 1.75
Sh "N22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 1.75
Sh "N23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 1.75
Sh "N24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 1.75
Sh "N25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 1.75
Sh "N26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 1.75
Sh "N27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 1.75
Sh "N28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 2.25
Sh "P1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 2.25
Sh "P2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 2.25
Sh "P3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 2.25
Sh "P4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 2.25
Sh "P5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 2.25
Sh "P6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 2.25
Sh "P7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 2.25
Sh "P8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 2.25
Sh "P9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 2.25
Sh "P10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 2.25
Sh "P11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 2.25
Sh "P12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 2.25
Sh "P13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 2.25
Sh "P14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 2.25
Sh "P15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 2.25
Sh "P16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 2.25
Sh "P17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 2.25
Sh "P18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 2.25
Sh "P19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 2.25
Sh "P20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 2.25
Sh "P21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 2.25
Sh "P22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 2.25
Sh "P23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 2.25
Sh "P24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 2.25
Sh "P25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 2.25
Sh "P26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 2.25
Sh "P27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 2.25
Sh "P28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 2.75
Sh "R1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 2.75
Sh "R2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 2.75
Sh "R3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 2.75
Sh "R4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 2.75
Sh "R5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 2.75
Sh "R6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 2.75
Sh "R7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 2.75
Sh "R8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 2.75
Sh "R9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 2.75
Sh "R10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 2.75
Sh "R11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 2.75
Sh "R12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 2.75
Sh "R13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 2.75
Sh "R14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 2.75
Sh "R15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 2.75
Sh "R16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 2.75
Sh "R17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 2.75
Sh "R18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 2.75
Sh "R19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 2.75
Sh "R20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 2.75
Sh "R21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 2.75
Sh "R22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 2.75
Sh "R23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 2.75
Sh "R24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 2.75
Sh "R25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 2.75
Sh "R26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 2.75
Sh "R27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 2.75
Sh "R28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 3.25
Sh "T1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 3.25
Sh "T2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 3.25
Sh "T3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 3.25
Sh "T4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 3.25
Sh "T5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 3.25
Sh "T6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 3.25
Sh "T7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 3.25
Sh "T8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 3.25
Sh "T9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 3.25
Sh "T10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 3.25
Sh "T11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 3.25
Sh "T12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 3.25
Sh "T13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 3.25
Sh "T14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 3.25
Sh "T15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 3.25
Sh "T16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 3.25
Sh "T17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 3.25
Sh "T18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 3.25
Sh "T19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 3.25
Sh "T20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 3.25
Sh "T21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 3.25
Sh "T22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 3.25
Sh "T23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 3.25
Sh "T24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 3.25
Sh "T25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 3.25
Sh "T26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 3.25
Sh "T27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 3.25
Sh "T28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.75 3.75
Sh "U1" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 3.75
Sh "U2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 3.75
Sh "U3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 3.75
Sh "U4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 3.75
Sh "U5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 3.75
Sh "U6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 3.75
Sh "U7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 3.75
Sh "U8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 3.75
Sh "U9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 3.75
Sh "U10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 3.75
Sh "U11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 3.75
Sh "U12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 3.75
Sh "U13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 3.75
Sh "U14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 3.75
Sh "U15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 3.75
Sh "U16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 3.75
Sh "U17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 3.75
Sh "U18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 3.75
Sh "U19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 3.75
Sh "U20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 3.75
Sh "U21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 3.75
Sh "U22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 3.75
Sh "U23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 3.75
Sh "U24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 3.75
Sh "U25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 3.75
Sh "U26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 3.75
Sh "U27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.75 3.75
Sh "U28" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.25 4.25
Sh "V2" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.75 4.25
Sh "V3" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.25 4.25
Sh "V4" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.75 4.25
Sh "V5" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.25 4.25
Sh "V6" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.75 4.25
Sh "V7" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.25 4.25
Sh "V8" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.75 4.25
Sh "V9" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.25 4.25
Sh "V10" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.75 4.25
Sh "V11" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.25 4.25
Sh "V12" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 4.25
Sh "V13" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 4.25
Sh "V14" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 4.25
Sh "V15" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 4.25
Sh "V16" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.25 4.25
Sh "V17" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.75 4.25
Sh "V18" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.25 4.25
Sh "V19" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.75 4.25
Sh "V20" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.25 4.25
Sh "V21" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.75 4.25
Sh "V22" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.25 4.25
Sh "V23" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.75 4.25
Sh "V24" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.25 4.25
Sh "V25" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.75 4.25
Sh "V26" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.25 4.25
Sh "V27" C 0.2 0.2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE BGA500C50P28X18_1400X900X130
$EndLIBRARY
